---
name: commissionpro
description: Build, deploy, update or troubleshoot the CommissionPro salon commission tracking app for Shahbaz Mirshahi. Use this skill whenever the user mentions CommissionPro, MGM Studio, the salon app, commission tracking app, Stripe payment setup, Supabase sync, GitHub Pages deployment, landing page, legal pages, customisation screen, theme, accent colour, Make.com automation, or any related feature. Also trigger when the user says things like "update the app", "fix the form", "change the colour", "add a feature", "something broken", or "test the flow". This skill contains the full architecture, all URLs, gotchas from past builds, and step-by-step procedures.
---

# CommissionPro Skill

A complete reference for building and maintaining the CommissionPro app — a salon commission tracker built for and with Shahbaz Mirshahi over multiple sessions.

---

## Architecture Overview

| Component | Service | URL / ID |
|-----------|---------|----------|
| App | GitHub Pages | `https://shaz010.github.io/mgm-studio/MGMStudio.html` |
| Landing page | GitHub Pages | `https://shaz010.github.io/mgm-studio/` |
| Database | Supabase | `https://vvqllhcwxqmchgrbkglh.supabase.co` |
| Supabase anon key | Supabase | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ2cWxsaGN3eHFtY2hncmJrZ2xoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyOTkxMjUsImV4cCI6MjA5Njg3NTEyNX0.qmp0S6BCI2sl84ilbPvNhaZFtWC6aCe30yDM12nfFpk` |
| Payments | Stripe (live) | `https://buy.stripe.com/3cIdR97x4gdA4z9dCEfw401` |
| Lead capture | Formspree | `https://formspree.io/f/maqzawkv` |
| Automation | Make.com | To be set up |
| GitHub repo | GitHub | `https://github.com/shaz010/mgm-studio` |
| Owner | Shahbaz Mirshahi | `chabokchamejun@gmail.com` |
| Bank | USAA | Linked to Stripe live account |

---

## File Structure (GitHub repo)

```
mgm-studio/
├── MGMStudio.html    — Main app (PWA, Supabase sync, customisation screen)
├── index.html        — Marketing landing page
├── thankyou.html     — Post-signup page with Stripe payment button
├── terms.html        — Terms of Service (GDPR/CCPA)
├── privacy.html      — Privacy Policy (GDPR/CCPA)
├── manifest.json     — PWA manifest
├── sw.js             — Service worker (offline mode)
├── icon-192.png      — App icon
├── icon-512.png      — App icon large
└── files.zip         — Old zip (ignore)
```

---

## Supabase Tables

```sql
-- appointments
id bigint primary key
name text
date text
time text
charge numeric
tip numeric
salon numeric
me numeric
mytotal numeric
cat text
created_at timestamp default now()

-- paid_months
month text primary key
paid_at bigint
```

RLS policies: Public access on both tables (all operations).

---

## App Features (MGMStudio.html)

- **New booking tab** — client name, category, date, time, charge, tip
- **Live earnings breakdown** — MGM split (configurable %), me split, tip (100% mine), total take-home
- **Appointments tab** — filterable table (all/month/week/today/weekly summary)
- **Weekly summary view** — grouped by week number (Wk28 format)
- **MGM owes me tab** — monthly commission accumulation, mark paid, invoice generator
- **Invoice generator** — print/PDF, professional layout, INV number
- **Edit/delete** appointments
- **Customisation screen** — first launch setup: name, salon, commission %, theme, accent colour
- **Settings gear icon** — change any setting anytime
- **Themes** — Dark, Light, Auto
- **Accent colours** — Gold, Rose, Ocean, Forest, Purple
- **PWA** — installable, offline capable, home screen icon
- **Sync badge** — shows Synced/Connecting/Offline in real time

---

## Commission Calculation (CRITICAL)

```
charge × MY_RATE = my commission (e.g. 60%)
charge × SALON_RATE = salon share (e.g. 40%)
tip = 100% mine, NEVER included in split
my total = my commission + tip
```

The commission rate is configurable per user via the customisation screen. Default is 60/40.

---

## Deployment Procedure

**To update any file:**
1. Build/edit file locally
2. Download from Claude outputs
3. Go to `github.com/shaz010/mgm-studio`
4. Click Add file → Upload files
5. Drop file(s) → Commit changes
6. Wait ~60 seconds for GitHub Pages to rebuild
7. Hard refresh browser: **Cmd+Shift+R**

**Critical:** Always hard refresh after deploying — browser cache causes old versions to show.

---

## Sales Flow (Automated)

```
Landing page → Signup form (Formspree) → Thank you page
→ Stripe payment ($49) → Make.com webhook
→ Instant email to customer (app link + setup instructions)
→ Notification to Shahbaz
→ Customer opens app → Customisation screen → Live
```

**Status:** Make.com automation still to be set up.

---

## ⚠ GOTCHA SECTION

These are real problems encountered during development. Check here before debugging anything.

### 1. Netlify "Page not found" / "Site not found"
**Problem:** Uploading `MGMStudio.html` to Netlify Drop gives 404.
**Cause:** Netlify requires the file to be named `index.html` OR zipped correctly.
**Fix:** Either rename to `index.html` before uploading, OR use the GitHub Pages deployment instead.
**Status:** Switched to GitHub Pages permanently. Do not use Netlify.

### 2. Netlify "Rename and deploy" option
**Problem:** Choosing "Rename and deploy" in Netlify broke the URL path.
**Fix:** Always choose "Deploy without renaming" if ever using Netlify Drop.

### 3. Browser cache shows old version after deployment
**Problem:** After uploading new file to GitHub, browser still shows old version.
**Fix:** Always press **Cmd+Shift+R** (hard refresh) after deployment. For testing use a Private/Incognito window.

### 4. Formspree shows white "Thanks!" page instead of custom thank you page
**Problem:** Formspree free plan locks the redirect feature behind a paid plan.
**Fix:** Use JavaScript `fetch()` to POST to Formspree in background, then use `window.location.href` to redirect manually. Do NOT use HTML `<form action="">` — it submits directly to Formspree and you lose control of redirect.
**Working code:**
```javascript
fetch('https://formspree.io/f/maqzawkv', {
  method:'POST',
  headers:{'Content-Type':'application/json','Accept':'application/json'},
  body: JSON.stringify({name, email, salon, ...})
}).finally(()=>{
  window.location.href='https://shaz010.github.io/mgm-studio/thankyou.html';
});
```

### 5. Stripe stuck in Sandbox mode
**Problem:** Stripe dashboard kept showing "Sandbox" badge and test products.
**Fix:** Click the CommissionPro name dropdown (top left) → look for "Test mode" toggle → switch off. OR go directly to `https://dashboard.stripe.com/live/payment-links`.
**Note:** Products created in sandbox do NOT carry over to live mode. Must recreate in live.

### 6. Supabase "offline" error
**Problem:** App shows "Offline" sync badge even when Supabase is healthy.
**Cause 1:** Tables not created yet → run the SQL in Supabase SQL Editor.
**Cause 2:** PWA service worker injected into the printInvoice JS template string.
**Fix for Cause 2:** The `sed` command for PWA injection must use Python string replacement, not sed, to avoid injecting into the template literal inside `printInvoice()`.

### 7. PWA service worker injected inside print template
**Problem:** Code leaked at the bottom of the rendered page.
**Cause:** `sed 's|</body>|...|'` matched the `</body>` inside the JS template literal in `printInvoice()`.
**Fix:** Use Python to find the LAST `</body>` tag (via `content.rfind('</body>')`) and inject before that only.

### 8. Tip calculation bug
**Problem:** Tip was being included in the 60/40 commission split instead of being kept 100% for the stylist.
**Fix:** Tips are calculated SEPARATELY. Formula: `myTotal = (charge × myRate) + tip`. Tips never touch the salon split. The earnings breakdown must show tip on its own line.

### 9. GitHub Pages URL structure
**App URL:** `https://shaz010.github.io/mgm-studio/MGMStudio.html`
**Landing:** `https://shaz010.github.io/mgm-studio/`
**Note:** The app is NOT at the root — it's at `/MGMStudio.html`. The landing page IS at root (`index.html`).

### 10. Stripe Sandbox vs Live products
**Problem:** CommissionPro $49 product created in sandbox doesn't appear in live mode.
**Fix:** Must create the product again in live mode. Go live → Product catalog → Create product → $49 one-off → then create payment link.

### 11. Supabase column name casing
**Problem:** App uses `mytotal` (lowercase) but some versions used `myTotal` (camelCase).
**Fix:** Supabase column is `mytotal` (all lowercase). Always use lowercase in SQL and JS when referencing this column.

### 12. Stripe payout schedule
**Setup:** USAA bank linked, automatic weekly payouts every Monday.
**Note:** First payout has a 7-day hold for new accounts — this is normal.

### 13. Formspree form not receiving submissions
**Problem:** Form submitted but no email received.
**Fix:** Check Formspree account email is verified (green checkmark in dashboard). The form ID is `maqzawkv`.

### 14. Make.com automation (not yet built)
**Status:** ⭕ Pending
**What it needs to do:**
- Trigger: Stripe webhook on `payment_intent.succeeded`
- Action 1: Send email to customer with app URL and setup instructions
- Action 2: Send notification email to `chabokchamejun@gmail.com`
**Free tier:** Make.com free plan supports 1000 operations/month — sufficient for early sales volume.

### 15. Two Macs sync lag
**Problem:** Claude conversation has ~5 minute sync lag between two Macs.
**Fix:** Press **Cmd+R** on the second Mac to force-refresh the conversation immediately.

---

## Legal Pages Status

| Page | Status | Coverage |
|------|--------|----------|
| terms.html | ✅ Live | No-refund, IP, limitation of liability, dispute resolution, GDPR Art.6, CCPA, binding arbitration, no class action |
| privacy.html | ✅ Live | Full GDPR, CCPA, data breach 72hr notification, SCCs, all third parties listed, rights grid |
| Consent checkbox | ✅ Live | "I agree, 18+, all sales final" — evidence against chargebacks |
| Cookie banner | ✅ Live | GDPR compliant, technically necessary only |

---

## Owner Info

- **Name:** Shahbaz Mirshahi
- **Business:** CommissionPro (unregistered sole proprietor)
- **Location:** Laguna Hills / Los Angeles area, California
- **Experience:** 20 years hair styling, colour and highlights
- **Salon:** MGM Salon (commission: 60% stylist / 40% salon)
- **Devices:** Mac (×2), iPhone 16 Pro Max, iPad M4
- **Gmail:** chabokchamejun@gmail.com
- **Mac email:** shahbazmirshahi@mac.com

---

## Next Steps (as of June 15, 2026)

1. ⭕ Upload latest legal files (terms.html, privacy.html, index.html) to GitHub
2. ⭕ Set up Make.com automation (Stripe → email customer → notify Shahbaz)
3. ⭕ Test full end-to-end flow with Stripe test card
4. ⭕ Add wallpaper backgrounds to app
5. ⭕ Market to MGM colleagues at $49/stylist
6. ⭕ Consider getcommissionpro.com domain ($12/yr)
