# CommissionPro — Social Media Posts

## 1. Facebook — Hairstylist Groups (US/UK/EU)

**Post for groups like "Hair Stylists Unite", "Salon Professionals", "Commission Stylists":**

---

✂️ Fellow commission stylists — do you actually know what the salon owes you right now?

I spent 20 years doing mental maths on my commission split at the end of every day. Writing things down on paper. Losing track. Never 100% sure if the numbers were right.

So I built something.

It's called **CommissionPro** — a simple app that:
✅ Calculates your exact commission split instantly (whatever % you're on)
✅ Tracks your tips separately — 100% yours, always
✅ Shows you exactly what the salon owes you each month
✅ Generates a professional invoice PDF
✅ Syncs across your iPhone, iPad and Mac
✅ Works offline at your chair — no WiFi needed
✅ Works in $ USD, £ GBP and € EUR

It's not a subscription. $49 once. Yours forever.

Built by a stylist who was tired of not knowing what they'd earned.

👉 getcommissionpro.com

Drop a 💇 below if you've ever had a commission dispute with your salon.

---

## 2. Instagram Caption

**Post a clean screenshot of the app earnings breakdown:**

Finally built what I always needed as a commission stylist 💇‍♀️✂️

20 years doing mental maths on my split. Never again.

CommissionPro tracks every client, calculates your exact commission, keeps your tips separate and shows what the salon owes you — all in one place.

Offline. Cloud synced. One-time $49. No subscriptions.

Link in bio 👆
getcommissionpro.com

#hairstylist #salonlife #commissionstyle #hairsalon #beautypro #salonowner #hairstylistlife #commission #stylistlife #beautyindustry #hairpro #salonwork #hairtips #beautytools #stylisttips

---

## 3. TikTok Script

**Film yourself at your station, talking to camera:**

"POV: you're a commission stylist and you have NO idea what the salon actually owes you this month.

Sound familiar? Yeah. I did that for 20 years.

So I built an app. You put in the charge — it splits your commission automatically. Tips stay 100% yours. At the end of the month it shows exactly what the salon owes you and generates an invoice.

It works offline at your chair. No WiFi needed. One time $49 — no subscription ever.

It's called CommissionPro. Link in bio."

Hashtags: #hairstylist #salonlife #commissioncheck #hairsalon #stylisttips #beautyindustry #hairtok #salonowner #commission

---

## 4. Facebook — UK Hairstylist Groups

**For groups like "UK Hair & Beauty Professionals", "British Hairstylists":**

---

✂️ UK stylists — how are you tracking your commission?

Still doing it on paper? In your head? Hoping the salon's numbers add up?

I built **CommissionPro** — a simple app that does it all for you:

✅ Instant commission split calculation (any %)
✅ Tips tracked separately — 100% yours
✅ Monthly summary — see exactly what the salon owes you
✅ Invoice generator — professional PDF in seconds
✅ Works offline at your chair
✅ £ GBP supported
✅ iPhone, iPad, Android, Mac

One-time £39 (~$49). No subscription. No monthly fees.

👉 getcommissionpro.com

---

## 5. Reddit — r/hairstylist, r/weddingplanning, r/beauty

**Title: "Built an app for commission stylists after 20 years of doing mental maths on my split"**

Body:
After two decades as a commission stylist, I got tired of never knowing exactly what I'd earned. Mental maths at the end of a long day, writing things on paper, hoping the salon's numbers matched mine.

So I built CommissionPro. It's a simple web app that:
- Calculates your exact commission split instantly
- Keeps tips 100% separate (they're yours, not the salon's)
- Shows your monthly total and what the salon owes you
- Generates a professional invoice PDF
- Works offline at your chair
- Syncs across all your devices
- Works in USD, GBP and EUR

It's $49 one time — no subscription. Works on any phone, tablet or computer.

Happy to answer any questions. Site is getcommissionpro.com

---

## 6. WhatsApp Message — to colleagues at MGM and other salons

Hey! 👋 I built something I think you'll actually use.

You know how we're always doing mental maths on our commission split? I made an app that does it automatically.

You put in the charge — it shows your cut, the salon's cut, and your tip separately. At the end of the month it shows exactly what MGM owes you. You can even generate an invoice PDF.

Works on your iPhone offline at your chair. $49 one time, no monthly fees.

Here's the link: https://shaz010.github.io/mgm-studio/

Would love to know what you think 🙏✂️

---

## 7. Email — to salon owner / manager introducing CommissionPro

Subject: A tool that helps your stylists track their commissions accurately

Hi [Name],

I wanted to share something I've built that I think could benefit the stylists at [Salon].

CommissionPro is a simple app that helps commission-based stylists track their earnings accurately — the commission split, tips, and monthly totals. It generates professional invoice PDFs and works offline at the salon chair.

I believe accurate commission tracking benefits everyone — stylists feel confident in their earnings, and salons avoid disputes.

The app is $49 per stylist, one-time fee. You can see it at:
https://shaz010.github.io/mgm-studio/

Happy to show you a demo.

Best,
Shahbaz Mirshahi
CommissionPro

---

## Domain Setup Instructions

**To get getcommissionpro.com:**

1. Go to **namecheap.com** or **godaddy.com**
2. Search: `getcommissionpro.com`
3. Buy for ~$12/year
4. In DNS settings add:
   - Type: CNAME | Name: www | Value: shaz010.github.io
   - Type: A | Name: @ | Values: 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153
5. In GitHub repo Settings → Pages → Custom domain → type getcommissionpro.com
6. Tick "Enforce HTTPS"
7. Wait 24 hours — your site is live at getcommissionpro.com!

**Google Search Console (makes Google find you):**
1. Go to search.google.com/search-console
2. Add property: getcommissionpro.com
3. Verify ownership (GitHub Pages method)
4. Submit sitemap

