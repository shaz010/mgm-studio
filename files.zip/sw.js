const CACHE = 'commissionpro-v2';
const OFFLINE_KEY = 'cp_offline_queue';

// All assets to cache for offline use
const ASSETS = [
  '/mgm-studio/MGMStudio.html',
  '/mgm-studio/manifest.json',
  '/mgm-studio/icon-192.png',
  '/mgm-studio/icon-512.png',
  'https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css',
  'https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/fonts/tabler-icons.woff2',
  'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2'
];

// Install — cache everything
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(cache => cache.addAll(ASSETS))
      .catch(() => {})
  );
  self.skipWaiting();
});

// Activate — clean old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch — cache first for app assets, network first for API calls
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  
  // For Supabase API calls — network first, fallback to cache
  if (url.hostname.includes('supabase.co')) {
    e.respondWith(
      fetch(e.request)
        .then(res => {
          const clone = res.clone();
          caches.open(CACHE).then(cache => cache.put(e.request, clone));
          return res;
        })
        .catch(() => caches.match(e.request))
    );
    return;
  }

  // For app files — cache first, then network
  e.respondWith(
    caches.match(e.request)
      .then(cached => {
        if (cached) return cached;
        return fetch(e.request).then(res => {
          const clone = res.clone();
          caches.open(CACHE).then(cache => cache.put(e.request, clone));
          return res;
        });
      })
      .catch(() => caches.match('/mgm-studio/MGMStudio.html'))
  );
});

// Listen for sync messages from the app
self.addEventListener('message', e => {
  if (e.data && e.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
